# Ejemplo de operadores de asignación
c = 10
c += 5
print("Asignación con acumulador: ", c)