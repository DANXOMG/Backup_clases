


#numero = int(input("Dame un número "))

#for i in range(1,11):
#    print(numero * i)
    
# Con funcion
def tabla_multiplicar ():
    numero = int(input("Dame un número"))
    for i in range(1,11):
        print(i, " x ", numero, " = ", i*numero)
tabla_multiplicar()