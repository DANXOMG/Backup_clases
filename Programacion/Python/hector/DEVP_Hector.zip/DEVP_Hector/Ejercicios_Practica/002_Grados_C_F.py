

def calcular_grados_C_F():
    celsius = float(input("Ingresa los grados Celsius: "))
    fha = (celsius * 9/5) + 32
    print (f"La temperatura en Fahrenheit es : {fha:.2f} ºF")
    
calcular_grados_C_F()