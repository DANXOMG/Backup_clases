# 16.- Promedio de calificaciones de un grupo.
# Solicita las calificaciones de un grupo de estudiantes y calcula el promedio.

from Ordenar_3_numeros import pedir_numeros


