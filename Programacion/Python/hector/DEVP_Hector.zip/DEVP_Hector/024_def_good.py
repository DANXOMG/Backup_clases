def pedir_valor():
    valor = int(input("Introduce un valor numérico: "))
    return valor

a = pedir_valor()
b = pedir_valor()
c = pedir_valor()
d = pedir_valor()
print("Valores introducidos: ", a, b, c, d)