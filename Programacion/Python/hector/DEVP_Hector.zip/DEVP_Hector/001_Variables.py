# Ejemplo1: Variable numérica
edad=25
print(edad)

#Ejemplo2: Variable de tipo cadena
cadena="Federico"
print(cadena)

#Ejemplo3: Variable tipo flotante
altura=1.75
print(altura)

#Ejemplo4: Variable Booleana
es_estudiante=True
print(es_estudiante)

#Ejemplo5: Variable lista
frutas=["manzana","pera","naranja"]
print(frutas)
print(frutas[1])

'''Ejemplo6: Variable tipo tupla'''
coordenadas=(10,20)
print(coordenadas)

#Ejemplo7: Variable tipo conjunto
colores={"rojo","azul","blanco","rosa"}
print(colores)

#Ejemplo8: Variable de tipo diccionario
persona={"nombre":"Ana","edad":30,"ciudad":"Madrid"}
print(persona)

#Ejemplo9: Variables y operaciones
a=10
b=5
suma=a+b
print(suma)