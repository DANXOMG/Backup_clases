def pedir_valor():
    print("Introduce un valor numérico: ")    
    
pedir_valor()
a = int(input())
pedir_valor()
b = int(input())
pedir_valor()
c = int(input())
pedir_valor()
d = int(input())
print("Valores introducidos: ", a, b, c, d)
