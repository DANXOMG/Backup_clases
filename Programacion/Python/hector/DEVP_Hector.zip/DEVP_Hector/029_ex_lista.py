def exListaF(n):
    exl = []
    for i in range(0,n):
        exl.insert(0,i)
        global med 
        med = divmod(1,3)
    return exl
print(exListaF(5))
print(med)