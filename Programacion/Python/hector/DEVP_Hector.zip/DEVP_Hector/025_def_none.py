def asir(valor):
    if valor == 0:
        return ("OK")

salida1 = asir(0)
print(salida1)
salida2 = asir(1)
print(salida2)
salida3 = asir(8)
print(salida3)
