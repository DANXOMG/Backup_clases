# Ejemplo de operadores a nivel de bits
num1 = 5
num2 = 3

result_AND = num1 & num2
result_OR = num1 | num2

print("Resultado del AND: ", result_AND)
print("Resultado del OR: ", result_OR)
