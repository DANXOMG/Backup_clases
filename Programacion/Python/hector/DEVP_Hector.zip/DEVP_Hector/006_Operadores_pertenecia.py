# Ejemplo de operadores de pertencia
lista = [1,2,4,5,6]
existe = 3 in lista
no_existe = 6 not in lista
print ("3 Esta está la lista: ", existe)
print("6 no existe en la lista: ", no_existe)