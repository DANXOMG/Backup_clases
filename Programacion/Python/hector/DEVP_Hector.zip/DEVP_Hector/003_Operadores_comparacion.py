# Ejemplo comparación
a=4
b=4
es_mayor_igual = a >= b
es_igual = a == b
print("Es mayor o igual: ",es_mayor_igual)
print("Es igual: ", es_igual)