def suma_lista(lst):
    suma = 0
    for elem in lst:
        suma+=elem
    return suma
print(suma_lista([5,4,3,6,5,2,8,9,7]))