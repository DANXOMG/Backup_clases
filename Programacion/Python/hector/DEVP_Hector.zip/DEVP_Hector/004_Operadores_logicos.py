# Ejemplo de operadores lógicos AND, OR,NOT
x = True
y = False

resultado_and = x and y
resultado_or = x or y
resultado_not = not x

print("AND: ", resultado_and, "\nOR: ", resultado_or, "\nNOT: ", resultado_not)