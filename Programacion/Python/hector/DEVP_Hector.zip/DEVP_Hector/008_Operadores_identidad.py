# Ejemplo de operadores de identidad , is , is not
benjamin = [1,2,3]
eugenio = benjamin
fernando = [1,2,3]

print("Benjamín es Eugenio? ", benjamin is eugenio)
print("Benjamín es Fernado? ", benjamin is fernando)
