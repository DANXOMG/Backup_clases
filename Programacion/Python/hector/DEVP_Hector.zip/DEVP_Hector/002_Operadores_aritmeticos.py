# Ejemplo 1: Sumar y resta
a=10
b=3
suma=a+b
resta=a-b
print("Suma: ", suma, " Resta: ",resta)

# Ejemplo 2: Multiplicación y división
a=10
b=2
multiplicacion=a+b
division=a-b
print("Multiplicacion: ", multiplicacion, "\nDivision: ",division)

print("Suma: ", suma, " Resta: ",resta)

# Ejemplo 3: División entera y módulo
a=10
b=2
divie = a // b
modu = a % b
print("División entera: ", divie, "\nMódulo: ",modu)

print("Suma: ", suma, " Resta: ",resta)

# Ejemplo 4: Potencia
a=5
b=2
potenc = a ** b
print("Potencia: ", potenc)