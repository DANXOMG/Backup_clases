def presentacion(nombre,apellido):
    print("Hola mi nombre es:",nombre,apellido)
    
presentacion("Héctor","Prieto")
presentacion(apellido="Suarez",nombre="Luis")
n = "Pepe"
a = "Díaz"
presentacion(n,a)
presentacion(a,n)